import com.mot.rfid.api3.*;
public class Reading_thread extends Thread {
	private Thread thread;
	private String name;
	private RFIDReader reader;
	private TagAccess.ReadAccessParams readparam;
	private AccessFilter accessfilter;
	Reading_thread(String Name, RFIDReader myreader){
		name = Name;
		reader = myreader;
		accessfilter.setRSSIRangeFilter(false);
		readparam.setMemoryBank(MEMORY_BANK.GetMemoryBankValue(1));
		
		
	}
	public void run() {
		while(true) {
			try {
				reader.Actions.TagAccess.readEvent(readparam, accessfilter, null);
			} catch (InvalidUsageException | OperationFailureException e) {
				e.printStackTrace();
			}
			try {
				sleep(300);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	public void start() {
		thread.start();
	}

}
