import com.mot.rfid.api3.*;
import java.util.ArrayList;
import java.io.*;
import org.apache.commons.csv.*;
import org.apache.commons.net.ftp.FTPClient;

public class Main {

	/*---------------------------INSTANTIATING GLOBAL VARIABLES-------------------------*/
	private static String Address = "0.0.0.0"; //Replace with actual IP address of the reader
	//Creating new object for the new RFID reader	
	private static RFIDReader reader = new RFIDReader(Address,0,30); //Connect to IP, Port 0, give 30 milliseconds for timeout
	private static ArrayList<TagData> Tag_list = new ArrayList<TagData>();
	/*---------------------------END INSTANTIATING OF VARIABLES-------------------------*/

	/*----------------------SETUP CODE THAT IS CALLED BEFORE MAIN LOOP------------------*/
	public static void setup() throws InvalidUsageException {
		/* ---------------Setting up the LLRP (Low Level Reader Protocol) connection----*/ 
		SecureConnectionInfo LLRP_Connect = new SecureConnectionInfo();
		LLRP_Connect.setSecureMode(true);
		LLRP_Connect.setValidatePeerCerticate(false);
		reader.SecureConnectionInfo = LLRP_Connect;
		/*------------------------------------------------------------------------------*/
		/* ---------------------------Setting up the Antennas---------------------------*/
		//RF Configurations
		try {
			Antennas.AntennaRfConfig[] Ant_RF_Conf = new Antennas.AntennaRfConfig[8];
			for(int i=0;i<8;i++) {
				Ant_RF_Conf[i].setTransmitPort(i); //Sets up port
				Ant_RF_Conf[i].setTransmitFrequencyIndex(920); //Set frequency to 920MHz
				Ant_RF_Conf[i].setTransmitPowerIndex(360); //Set it up for 36.0 dbm (4W)
				Ant_RF_Conf[i].setTari(3); //3 mS Tari
			}
			for(int i=0;i<8;i++)reader.Config.Antennas.setAntennaRfConfig(i, Ant_RF_Conf[i]);

		}catch(OperationFailureException e) {
			System.out.println("something went wrong readers RF capablility cant be configured... womp-womp");
			e.printStackTrace();
		}
		//Non RF Configurations
		try {
			Antennas.Config[] Ant_Conf = new Antennas.Config[8];
			short TX_Power = 360;
			short RX_Sen = -88;
			short TX_Freq = 920;
			for(int i=0;i<8;i++) {
				Ant_Conf[i].setTransmitFrequencyIndex(TX_Freq);//set the frequency to 920MHz
				Ant_Conf[i].setTransmitPowerIndex(TX_Power);//set it up for 36.0 dbm (4W)
				Ant_Conf[i].setReceiveSensitivityIndex(RX_Sen);//set the sensitivity to 1.2pW
			}
			for(int i=0;i<8;i++)reader.Config.Antennas.setAntennaConfig(i,Ant_Conf[i]); //Writing the antennas to the reader


		}catch(OperationFailureException e) {
			System.out.println("something went wrong reader cant be configured... womp-womp");
			e.printStackTrace();
		}
		/*----------------------------------------------------------------------------------*/
		/* ----------------------------Connecting the reader--------------------------------*/
		event_listen eventsHandler = new event_listen();
		try{
			reader.connect();
			reader.Events.addEventsListener(eventsHandler);
			reader.Events.setGPIEvent(true);
		}
		catch(OperationFailureException e) {
			System.out.println("Something went wrong reader cant connect... womp-womp");
			e.printStackTrace();
		}
		/*----------------------------------------------------------------------------------*/
		/* -------------------Enable GPI Ports to Trigger the ISR---------------------------*/
		try {
			reader.Config.GPI.enablePort(1,true);
		} catch (OperationFailureException e) {
			System.out.println("Something went wrong when trying to set GPI :(");
			e.printStackTrace();
		}
		/*------------------------------------------------------------*/
		/*--------------------Cable Loss Compensation-----------------*/
		ReaderManagement reader_manager = new ReaderManagement();
		CableLossCompensation[] loss_comp = new CableLossCompensation[8];
		for(int i=0; i<8;i++) {
			loss_comp[i] = new CableLossCompensation();
			loss_comp[i].setAntennaID(i);
			loss_comp[i].setCableLengthInFeet(3F);
		}
		try {
			reader_manager.setCableLossCompensation(loss_comp);
		}
		catch(OperationFailureException e) {
			System.out.println("could not compensate for cable :(");
			e.printStackTrace();
		}


	}
	/*---------------------------------------------END SETUP----------------------------------------------------------*/


	/*------------------------------------------RFID EVENT CLASS------------------------------------------------------*/
	static class event_listen implements RfidEventsListener {
		public event_listen() {

		}
		public void eventReadNotify(RfidReadEvents e) { //Inherited method of RfidEventListener, needs to exist

		}
		/*-----------------------------------GPI EVENT INTERUPT----------------------------------------------------------*/
		//THE GPI EVENT TRIGGERS ON A ANY CHANGE OF GPI LEVEL (LO-HI & HI-LO)

		public void eventStatusNotify(RfidStatusEvents e) {
			//this is to make sure that the reader doesn't activate when the forklift goes back over
			int flag = 1;
			while(flag == 1) {
				try {
					if(reader.Config.GPI.getPortState(1) == GPI_PORT_STATE.GPI_PORT_STATE_HIGH) {
						ArrayList<String> black_listed_tags = new ArrayList<String>();
						try {
							black_listed_tags = Main.import_files();
						} catch (IOException e2) {
							black_listed_tags.add(null);
							e2.printStackTrace();
						}
						int count = 0;
						while(Tag_list.size() < 10) { //keep on scanning until we get at least 10 valid measurements
							count++;
							if(count==10000)break; //break out if we get many empty scans
							TagDataArray Tagsarray = new TagDataArray(); 
							Tagsarray = reader.Actions.getReadTagsEx(30); //can read up to 30 tags, all non populated values in the array will default to null
							TagData Tags_scanned[] = new TagData[Tagsarray.getLength()];
							Tags_scanned = Tagsarray.getTags();
							//Moving the tag list array to an ArrayList data type
							ArrayList<TagData> Tag_list_inte = new ArrayList<TagData>();
							for(int i = 0; i < Tags_scanned.length;i++)Tag_list_inte.add(Tags_scanned[i]);
							//Removing null data 
							for(int i = 0; i<Tag_list_inte.size();i++)if(Tag_list_inte.contains(null))Tag_list_inte.remove(null); //Removing any wrong scans
							for(TagData curr_tag:Tag_list_inte) {
								Tag_list_inte.remove(curr_tag);
								if(!Tag_list_inte.contains(curr_tag))Tag_list.add(curr_tag); //Removing duplicated tags
							}
						}
						
						//Checking for flagged tags
						for(int i=1;i==black_listed_tags.size();i++) {
						if(Tag_list.contains(black_listed_tags.get(i)))reader.Config.GPO.setPortState(0, GPO_PORT_STATE.TRUE);
						}

						try {
							Main.writefiles(Tag_list); //Once we back out of the loop, write the files to the server
						} catch (FileNotFoundException e1) {
							e1.printStackTrace();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
						Tag_list.clear();
					}
				} catch (InvalidUsageException | OperationFailureException e1) {
					e1.printStackTrace();
				}
				try {
					if(reader.Config.GPI.getPortState(1)==GPI_PORT_STATE.GPI_PORT_STATE_LOW)flag=1;
				} catch (InvalidUsageException | OperationFailureException e1) {
					e1.printStackTrace();
				}
			} 
		}
		/*-----------------------------------END OF GPI EVENT INTERUPT-----------------------------------------------------*/
	}
	/*----------------------------------------END OF RFID EVENT CLASS------------------------------------------------------*/

	/*---------------------------------MAIN METHOD FOR IMPORTING BLACKLIST FILES-------------------------------------------*/
	public static ArrayList<String> import_files() throws FileNotFoundException, IOException {
		/*------------------------------Login into FTP Client ---------------------------------------------------*/	
		String home = System.getProperty("user.home");
		String savepath = home+"/Documents/Eclipse/Zebra-FXSeries-Embedded-SDK-Java_Linux/";
		FTPClient client = new FTPClient();
		client.connect("192.168.56.1"); //address of dummy ftp server
		client.login("anonymous",""); //username and password
		/* -------------------------------------------------------------------------------------------------------*/
		/* ----------------------------------Local Save Paths-----------------------------------------------------*/
		File local_location_to_store = new File(savepath+"QualityHold.csv");
		String server_source = "QualityHold.csv"; //name of csv we are looking for
		client.retrieveFile(server_source,new FileOutputStream(local_location_to_store));
		/* -------------------------------------------------------------------------------------------------------*/
		/* -------------------------------Reading the retrieved info----------------------------------------------*/
		Reader reading = new FileReader(savepath+"QualityHold.csv");
		ArrayList<String> blacklisted = new ArrayList<String>();
		CSVParser parsed_hams = new CSVParser(reading,CSVFormat.EXCEL.withFirstRecordAsHeader());
		for(CSVRecord record:parsed_hams) blacklisted.add(record.get("QC"));
		/* -------------------------------------------------------------------------------------------------------*/
		parsed_hams.close(); //Close the parser
		client.logout(); //Log out of the FTP Client
		return(blacklisted); //Return the blacklisted tags
	}
	/*----------------------------END OF MAIN METHOD FOR IMPORTING BLACKLIST FILES-------------------------------*/

	/*-----------------------------------------------------------------------------------------------------------*/

	/*-----------------------------MAIN METHOD FOR EXPORTING LIST OF TAGS SEEN-----------------------------------*/
	public static void writefiles(ArrayList<TagData> tags_Scanned) throws FileNotFoundException, IOException {
		/*------------------------------Login into FTP Client ---------------------------------------------------*/	
		String home = System.getProperty("user.home");
		String savepath = home+"/Documents/Eclipse/Zebra-FXSeries-Embedded-SDK-Java_Linux/";
		FTPClient client = new FTPClient();
		client.connect("192.168.56.1");
		client.login("anonymous","");
		/* -------------------------------------------------------------------------------------------------------*/
		/* ----------------------Creating local path for files to sent to the server------------------------------*/
		FileWriter sending_data = new FileWriter(savepath+"Order_num.csv");
		sending_data.append("Tires sent at bay door: " + 1);
		sending_data.append("\n");
		for(int i=1;i<=(tags_Scanned.size());i++) {
			sending_data.append(tags_Scanned.get(tags_Scanned.size()-i).toString());
			sending_data.append("\n");
		}
		/* -------------------------------------------------------------------------------------------------------*/
		/* ----------------------------------Closing the filewriter-----------------------------------------------*/
		sending_data.flush();
		sending_data.close();
		/* -------------------------------------------------------------------------------------------------------*/
		/* --------------------------------Sending data and then logout-------------------------------------------*/
		File Tires_to_Send = new File(savepath+"Order_num.csv");
		client.storeFile("Order_num.csv",new FileInputStream(Tires_to_Send));
		client.logout();
		return;

	}
	/*--------------------------------END OF MAIN METHOD FOR EXPORTING TAGS SEEN----------------------------------*/

	public static void main(String[] args) throws InvalidUsageException{
		setup(); //sets up the reader and antenna combo
		while(true) {//creates a main infinite loop after setup	
			assert true; //Nop
		}

	}
}

